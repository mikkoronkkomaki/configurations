0=${(%):-%N}
source ${0:A:h}/zsh-syntax-highlighting.zsh
